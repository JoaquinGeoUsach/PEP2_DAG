# librerias
import pandas as pd
import geopandas as gpd
import sys
import json
from sqlalchemy import create_engine, text
from geoalchemy2 import Geometry
from shapely.geometry import shape
from shapely.wkt import dumps as wkt_dumps


def execute_sql_query(mapstore_engine, sql_query):

    with mapstore_engine.connect().execution_options(autocommit=True) as con:
        con.execute(sql_query)
        con.commit()
    print("[OK] - SQL query successfully executed")

def open_sql_query(sql_file, ):

    with open("./sql_queries/" + sql_file, encoding = "utf8") as file:
        sql_query = text(file.read())
    print("[OK] - " + sql_file + " SQL file successfully opened")
    return sql_query
 
def df_to_db(df, config_data, db_object, mapstore_engine, table_name):
    """Copy the IDE DataFrames to the mapstore database.

    Args:
        df (pandas.core.frame.DataFrame): Dataframe from IDE service.
        config_data (dict): config.json parameters.
        mapstore_engine (sqlalchemy.engine.base.Engine): Mapstore DB sqlalchemy engine.
        table_name (str): Name of the output table on the mapstore's database.
    
    Raises:
        SAWarning: Did not recognize type 'geometry' of column 'geom'
    """

    df.to_sql(table_name, 
                mapstore_engine, 
                if_exists = 'replace', 
                schema = config_data[db_object]['schema'], 
                index = False)

    print("[OK] - " + table_name + " dataframe successfully copied to Mapstore database")

def connect_to_engine(db_engine, config_data, db_object):
    """Connects to sqlalchemy database engine.

    Args:
        db_engine (sqlalchemy.engine.base.Engine): SQLAlchemy database engine.
        config_data (dict): config.json parameters.
        db_object (str): Name of the DB object specified on the config.json file.

    Returns:
        sqlalchemy.engine.Connection.connect
    """

    db_type = config_data[db_object]['db_type']

    if db_type == 'postgresql':
        db_con = db_engine.connect()

    else:
        db_con = db_engine.connect().execution_options(autocommit=False)
    
    print('[OK] - SQLAlchemy connection succesfully generated')
    return db_con

def create_db_engine(config_data, db_object, db_string):
    """Creates the SQL Alchemy db engine. 

    Args:
        config_data (dict): config.json parameters.
        db_object (str): Name of the DB object specified on the config.json file.
        db_string (str):  Mapstore database connection string.
    
    Returns:
        sqlalchemy.engine.base.Engine.
    """

    try:
        db_type = config_data[db_object]['db_type']

        if db_type == 'postgresql':
            db_engine = create_engine(db_string)
            print("[OK] - SQLAlchemy engine successfully created")
            return db_engine

        else:
            conn_args={
                "TrustServerCertificate": "yes",
                "Echo": "True",
                "MARS_Connection": "yes"}

            db_engine = create_engine(db_string, connect_args=conn_args)
            print("[OK] - SQLAlchemy engine succesfully generated")
            return db_engine

    except Exception as e:
        print("[ERROR] - Creating the database connection engine")
        print(e)
        sys.exit(2)

def create_db_string(config_data, db_object):
    """Create database connection string based on the config file parameters.

    Args:
        config_data (dict): config.json parameters.
        db_object (str): Name of the DB object specified on the config.json file.

    Returns:
        str
    """

    db_string = '{}://{}:{}@{}:{}/{}'.format(
        config_data[db_object]['db_type'],
        config_data[db_object]['user'],
        config_data[db_object]['passwd'], 
        config_data[db_object]['host'], 
        config_data[db_object]['port'], 
        config_data[db_object]['db'])

    # Case if the DB is SQL Server
    if config_data[db_object]['db_type'] == 'mssql+pyodbc':
        db_string = db_string + '?driver=ODBC+Driver+17+for+SQL+Server'
    
    print("[OK] - Connection string successfully generated")
    return db_string 

def get_config(filepath=""):

    if filepath == "":
        sys.exit("[ERROR] - Config filepath empty.")

    with open(filepath) as json_file:
        data = json.load(json_file)

    if data == {}:
        sys.exit("[ERROR] - Config file is empty.")

    return data

def get_parameters(argv):

    config_filepath = argv[1]
    return config_filepath

def main(argv):
    # json agregado 
    argv = ["pep_dag.py", "config.json"]

    # Get parameters
    config_filepath = get_parameters(argv)
    config_data = get_config(config_filepath)

    print(config_data)

    # Rutas corregidas
    gdf1 = gpd.read_file(r"C:/Users/diego/Desktop/PEP 2 DAG/Entradas/predios_normados/predios_normados.shp")
    gdf2 = gpd.read_file(r"C:/Users/diego/Desktop/PEP 2 DAG/Entradas/manzanas_colina/manzanas_colina.shp")
    gdf3 = gpd.read_file(r"C:/Users/diego/Desktop/PEP 2 DAG/Entradas/redvial_colina/redvial_colina.shp")
    

    # Crear string de conexión
    postgres_string = create_db_string(config_data, 'database')
    postgres_connection = create_db_engine(config_data, 'database', postgres_string)

    print(postgres_connection)

      # Eliminar geometría si existe
# ⚠️ NO ELIMINES LA COLUMNA 'geometry'
# df1 = gdf1.drop(columns='geometry', errors='ignore')

# Eliminar geometría si existe
    df1 = gdf1.copy()
    if 'geometry' in df1.columns:
       df1['geometry'] = df1['geometry'].apply(lambda geom: wkt_dumps(geom) if geom else None)
    table_name = 'predios_normados'
    df_to_db(df1, config_data, 'database', postgres_connection, table_name)
    print("[OK] - Tabla predios_normados procesada y cargada correctamente.")

    df2 = gdf2.copy()
    if 'geometry' in df2.columns:
       df2['geometry'] = df2['geometry'].apply(lambda geom: wkt_dumps(geom) if geom else None)
    table_name = 'manzanas_colina'
    df_to_db(df2, config_data, 'database', postgres_connection, table_name)
    print("[OK] - Tabla manzanas_colina procesada y cargada correctamente.")

    df3 = gdf3.copy()
    if 'geometry' in df3.columns:
       df3['geometry'] = df3['geometry'].apply(lambda geom: wkt_dumps(geom) if geom else None)
    table_name = 'redvial_colina'
    df_to_db(df3, config_data, 'database', postgres_connection, table_name)
    print("[OK] - Tabla redvial_colina procesada y cargada correctamente.")

    # # Open the 'sql' file
    add_geometry_query = open_sql_query("add_geometry.sql")

    # # Execute the SQL query to transform the geometry type of the new tables
    execute_sql_query(postgres_connection, add_geometry_query)

        # # Open the 'sql' file
    dens_pob_predios_query = open_sql_query("dens_pob_predios.sql")

    # # Execute the SQL query to transform the geometry type of the new tables
    execute_sql_query(postgres_connection, dens_pob_predios_query)

        # # Open the 'sql' file
    vias_predios_query = open_sql_query("vias_predios.sql")

    # # Execute the SQL query to transform the geometry type of the new tables
    execute_sql_query(postgres_connection, vias_predios_query)

            # # Open the 'sql' file
    schema_salidas_query = open_sql_query("schema_salidas.sql")

    # # Execute the SQL query to transform the geometry type of the new tables
    execute_sql_query(postgres_connection, schema_salidas_query)

                # # Open the 'sql' file
    tabla_final_query = open_sql_query("tabla_final.sql")

    # # Execute the SQL query to transform the geometry type of the new tables
    execute_sql_query(postgres_connection, tabla_final_query)



if __name__ == "__main__":
    main(sys.argv)

