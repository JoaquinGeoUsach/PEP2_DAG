-- Calcular la cantidad de vías dentro de un radio de 20 metros de cada predio
SELECT 
    p.id AS predio_id,
    COUNT(r.id) AS cantidad_vias
FROM 
    entradas.predios_normados AS p
LEFT JOIN 
    entradas.redvial_colina AS r
ON 
    ST_DWithin(p.geometry, r.geometry, 20) -- Condición de distancia de 20 metros
GROUP BY 
    p.id;