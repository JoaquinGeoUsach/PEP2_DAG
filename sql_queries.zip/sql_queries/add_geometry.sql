--Cambia las geometrias de string a geom
ALTER TABLE entradas.predios_normados
ADD COLUMN geom geometry;

UPDATE entradas.predios_normados
SET geom = ST_GeomFromText(geometry, 4326);

ALTER TABLE entradas.manzanas_colina
ADD COLUMN geom geometry;

UPDATE entradas.manzanas_colina
SET geom = ST_GeomFromText(geometry, 4326);

ALTER TABLE entradas.redvial_colina
ADD COLUMN geom geometry;

UPDATE entradas.predios_normados
SET geom = ST_GeomFromText(geometry, 4326);
