--Crear el esquema 'salidas' si no existe
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = 'salidas') THEN
        EXECUTE 'CREATE SCHEMA salidas';
    END IF;
END $$;

