-- Eliminar la tabla si ya existe
DROP TABLE IF EXISTS salidas.predios_normados_con_indice;

-- Crear la tabla 'predios_normados_con_indice' en el esquema 'salidas'
CREATE TABLE salidas.predios_normados_con_indice AS 
SELECT 
    p.*,
    v.cantidad_vias,
    d.densidad_promedio,
    (v.cantidad_vias * 0.6 + d.densidad_promedio * 0.4) AS indice_final 
FROM 
    entradas.predios_normados AS p
LEFT JOIN 
    (-- Subconsulta para cantidad de vías
     SELECT 
         p.id AS predio_id,
         COUNT(r.id) AS cantidad_vias
     FROM 
         entradas.predios_normados AS p
     LEFT JOIN 
         entradas.redvial_colina AS r
     ON 
         ST_DWithin(p.geometry, r.geometry, 20)
     GROUP BY 
         p.id
    ) AS v
ON p.id = v.predio_id
LEFT JOIN 
    (-- Subconsulta para densidad poblacional promedio
     SELECT 
         p.id AS predio_id,
         AVG(m.dens_pobla) AS densidad_promedio 
     FROM 
         entradas.predios_normados AS p
     LEFT JOIN 
         entradas.manzanas_colina AS m
     ON 
         ST_DWithin(p.geometry, m.geometry, 500)
     GROUP BY 
         p.id
    ) AS d
ON p.id = d.predio_id;

-- Verificar si la geometría está registrada en geometry_columns
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 
        FROM geometry_columns 
        WHERE f_table_schema = 'salidas' 
          AND f_table_name = 'predios_normados_con_indice' 
          AND f_geometry_column = 'geometry'
    ) THEN
        INSERT INTO geometry_columns (
            f_table_catalog, 
            f_table_schema, 
            f_table_name, 
            f_geometry_column, 
            coord_dimension, 
            srid, 
            type
        ) 
        VALUES (
            current_database(), 
            'salidas', 
            'predios_normados_con_indice', 
            'geometry', 
            2, 
            4326, 
            'MULTIPOLYGON'
        );
    END IF;
END $$;

-- Otorgar permisos de acceso a la tabla
GRANT SELECT ON salidas.predios_normados_con_indice TO PUBLIC;