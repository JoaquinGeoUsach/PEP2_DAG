-- Calcular la densidad poblacional promedio en un radio de 500 metros
SELECT 
    p.id AS predio_id,
    AVG(m.dens_pobla) AS densidad_promedio
FROM 
    entradas.predios_normados AS p
LEFT JOIN 
    entradas.manzanas_colina AS m
ON 
    ST_DWithin(p.geometry, m.geometry, 500) -- Condición de distancia de 500 metros
GROUP BY 
    p.id;